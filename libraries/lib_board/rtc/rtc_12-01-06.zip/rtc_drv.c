//***************************************************************************
//! @file $RCSfile: rtc_drv.c,v $
//!
//! Copyright (c) 2005 Atmel.
//!
//! Please read file license.txt for copyright notice.
//!
//! @brief RTC (Real Time Counter) routines.
//!
//! These routines need some #define's of "board.h" file.
//!
//! @version $Revision: 2.00 $ $Name: jtellier $ 
//!
//! @todo
//! @bug
//***************************************************************************

//_____  I N C L U D E S ___________________________________________________

#include "config.h"
#include "rtc_drv.h"

//_____ M A C R O S ________________________________________________________

//_____ D E F I N I T I O N S ______________________________________________

//_____ D E C L A R A T I O N S ____________________________________________

U8 rtc_seconds;
U8 rtc_minutes;
U8 rtc_hours;
U8 rtc_days;

//***************************************************************************
//  @fn wait_for
//!
//! Timer2 initialization for audio transducer on DVK90CAN1 board.
//!
//! @warning RTC_TIMER & RTC_CLOCK must be define in board.h
//!
//! @param U16 - wait value in ms
//!
//! @return (none)
//!
//***************************************************************************
void wait_for(U16 ms_count)
{
#if (RTC_TIMER == 2)
#   if (RTC_CLOCK == 32)

    Bool  pr_tc2_1024 = FALSE;
    TCCR2A = 0x00;    // Timer 2 initialized "OFF"
    ASSR  =  (1<<AS2); ASSR &= ~(1<<EXCLK);    // Init RTC clock
    // Prescaler frequency
    // -> 32.768KHz/32   ==> 0.9765625 ms, so close to  1 ms !!!)
    // -> 32.768KHz/1024 ==>    31.250 ms, so close to 32 ms !!! => max 8192 ms)
    TCCR2A |= (3<<CS20);
    if (ms_count >= 256)  // Prescaler setting
    {
        TCCR2A |= (1<<CS22);
        pr_tc2_1024 = TRUE;
    }
    if (ms_count >= 8192) // Upper limit verification
    {
        ms_count = 8192;
    }

    TCCR2A |= (1<<WGM21)|(0<<WGM20 );         // Mode 2: CTC on top=OCR, toggle OC2A
    OCR2A = (ms_count>>(5*pr_tc2_1024))-1;    // Set TOP value in OCR2A register
    GTCCR |= (1<<PSR2);                       // Reset Timer 2 prescaler
    TCCR2A |= ((0<<COM2A1) | (1<<COM2A0));    // Timer 2 toogle mode (RTC "ON")
      
    while ((TIFR2 & 0x02) == 0);    // Wait for end of counting
    TIFR2 = 0x03;     // Reset end of counting flag
    TCCR2A = 0x00;    // Timer 2  "OFF"

#   endif // RTC_CLOCK
#endif // RTC_TIMER
}

//***************************************************************************
//  @fn rtc_int_init
//!
//! Timer2 initialization second counteur managed under interrupt.
//!
//! @warning RTC_TIMER & RTC_CLOCK must be define in board.h
//!
//! @param (none)
//!
//! @return (none)
//!
//***************************************************************************
void rtc_int_init(void)
{
#if (RTC_TIMER == 2)
#   if (RTC_CLOCK == 32)

    asm("cli");

    TCCR2A = 0x00;          // Timer 2 initialized "OFF"
    wait_for(1000);         // Wait for 1 sec to let the Xtal stabilize after a power-on,
    TIMSK2 = 0;             // Disable OCIE2A and TOIE2

    ASSR  =  (1<<AS2); ASSR &= ~(1<<EXCLK); // Init RTC clock
    TCNT2 = 0;                              // Clear TCNT2A
    TCCR2A |= (1<<CS22) | (1<<CS20);        // Select precaler: 32.768 kHz / 128 = 1 sec between each overflow

    while((ASSR & (1<<TCR2UB)) | (ASSR & (1<<TCN2UB)));   // Wait for TCN2UB and TCR2UB to be cleared

    TIFR2 = 0xFF;           // Clear interrupt-flags
    TIMSK2 |= 1<<TOIE2;     // Enable Timer2 overflow interrupt

    asm("sei");

    // Time setting
    rtc_seconds = 0;
    rtc_minutes = 0;
    rtc_hours   = 0;
    rtc_days   = 0;

#   endif // RTC_CLOCK
#endif // RTC_TIMER
}

//***************************************************************************
//  @fn 
//!
//! Timer2 overflow interrupt routine. Increment the real-time clock, the
//! interrupt occurs once a second (running from the 32,768 kHz crystal)
//!
//! @warning RTC_TIMER & RTC_CLOCK must be define in board.h
//!
//! @param (none)
//!
//! @return (none)
//!
//***************************************************************************
INTERRUPT(SIG_OVERFLOW2)
{
#if (RTC_TIMER == 2)
#   if (RTC_CLOCK == 32)

    rtc_seconds++;              // Increment seconds

    if (rtc_seconds == 60)
    {
        rtc_seconds = 0;
        rtc_minutes++;          // Increment minutes
        
        if (rtc_minutes == 60)
        {
            rtc_minutes = 0;
            rtc_hours++;        // Increment hours
                    
            if (rtc_hours == 24)
            {
                rtc_hours = 0;
                rtc_days++;     // Increment days
            }
        }
    }
#   endif // RTC_CLOCK
#endif // RTC_TIMER
}
